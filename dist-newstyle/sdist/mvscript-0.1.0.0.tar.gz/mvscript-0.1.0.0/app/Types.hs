module Types where

data Type =
    String String
    | Int Integer
    | Float Float
    | Vector [Double] 
    | Point [Double]
    | Matrix [[Double]] 
