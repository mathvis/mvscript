module Parser where 
import Text.ParserCombinators.Parsec
import Types

parseContents :: Parser Type
parseContents = parseString <|> parseInt
    
parseString :: Parser Type
parseString =
    do
        char '"'
        x <- many (noneOf "\"")
        char '"'
        return $ String x

parseInt :: Parser Type
parseInt = Int . read <$> many1 digit

parseFloat :: Parser Type
parseFloat = Float . read <$> many1 digit
